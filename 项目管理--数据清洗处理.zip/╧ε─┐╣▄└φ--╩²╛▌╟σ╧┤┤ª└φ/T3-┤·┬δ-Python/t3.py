import pandas as pd
import chardet

# 设置显示所有列
pd.set_option('display.max_columns', None)

# 读取CSV文件
file_path = 'C:/Users/Tesia74286/Desktop/测试题/测试题.csv'  

# 检测文件编码
with open(file_path, 'rb') as f:
    result = chardet.detect(f.read()) 

# 使用检测到的编码读取CSV文件
data = pd.read_csv(file_path, encoding=result['encoding'])

# 初始化一个空的列表来存储转换后的数据
transformed_data = []

# 遍历每一行数据
for index, row in data.iterrows():
    chapter_name = str(row[0]) if pd.notna(row[0]) else None  # 章节名称在第一列，确保转换为字符串
    if chapter_name is not None:  # 如果章节名称不为空
        for col in range(1, len(row)):  # 从第二列开始遍历知识点名称
            if pd.notna(row[col]):  # 如果该单元格不为空
                knowledge_point_name = str(row[col])  # 确保知识点名称转换为字符串
                transformed_data.append([chapter_name, knowledge_point_name])


# 创建DataFrame之前，处理列名以移除重复
unique_chapter_names = list(set([td[0] for td in transformed_data]))
unique_knowledge_point_names = list(set([td[1] for td in transformed_data]))

# 将转换后的数据转换为DataFrame
transformed_df = pd.DataFrame(transformed_data, columns=['章节名称', '知识点名称'])

# 指定新的Excel文件路径
new_file_path = 'C:/Users/Tesia74286/Desktop/测试题/转换后的测试题.xlsx'

# 将DataFrame保存到新的Excel文件中
transformed_df.to_excel(new_file_path, index=False, sheet_name='转换后的数据')

# 打印提示信息
print(f"数据已成功保存到新的Excel文件：{new_file_path}")